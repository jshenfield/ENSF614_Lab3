/*
* File Name: main.cpp
* Assignment: Lab 3 Exercise A
* Lab Section: B01
* Completed by: Jack Shenfield & Barrett Sapunjis
* Submission Date: Oct 1, 2025
*/

#include "graphicsWorld.h"

int main() {
    graphicsWorld gw;   // make a graphicsWorld object
    gw.run();           // run all the tests inside run()
    return 0;
}
