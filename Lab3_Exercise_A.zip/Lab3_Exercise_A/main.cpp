#include "graphicsWorld.h"

int main() {
    graphicsWorld gw;   // make a graphicsWorld object
    gw.run();           // run all the tests inside run()
    return 0;
}
